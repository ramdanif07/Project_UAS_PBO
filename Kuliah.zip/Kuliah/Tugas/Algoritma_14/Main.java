public class Main 
{
    public static void main(String[] args)
    {
        // variable
        String kata = "Nusa Putra";
        int key = 12;
        String[] huruf = new String[26];

        // isi array huruf
        for(char c = 'A'; c<= 'Z'; c++)
        huruf [c - 65] = String.valueOf(c);
    }
}
