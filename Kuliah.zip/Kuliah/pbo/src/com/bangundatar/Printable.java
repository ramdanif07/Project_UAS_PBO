package com.bangundatar;

/**
 * Printable
 */
interface Printable {
    void print();
    void setPaper(String paper);
}
