package com.emoney;

public class Dana implements DigitalMoney, Bank{
    private String nomerAccount;

    public Dana (String nomerAccount){
        this.nomerAccount = nomerAccount;
    }
    
    public void topUp(int amount){
        System.out.println("Top Up:" + amount);
    }

    public String getNomorAccount(){
        return nomerAccount;
    }

    public void pay(int amount){
        System.out.println("Pay:" + amount);
    }

    public void checkBalance(){
        System.out.println("Check blance");
    }

    public void withdraw(int amount){
        System.out.println("withdraw:" + amount);
    }

    public void transfer(int amount, String accountNumber){
        System.out.println ("Transfer:" + amount + "to" + accountNumber);
    }
}
