package com.emoney;

public interface Printable {
    void print();    
}
