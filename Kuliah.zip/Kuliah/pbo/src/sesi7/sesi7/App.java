package sesi7;

public class App {
    public static void main(String[] args ) throws Exception{
        LibMath<Integer, Integer> LibMath = new LibMath<>(angka1:10, angka2:20);
        LibMath<Double, Double> LibMath2 = new LibMath<>(angka1:10.0, angka2:10.0);
        LibMath<Integer, Double> LibMath3 = new LibMath<>(angka1:10, angka2:20.0);
        LibMath<Double, Integer> LibMath4= new LibMath<>(angka1:10.0, angka2:10);
        LibMath.add();
        LibMath2.add();
        LibMath3.add();
        LibMath4.add();

        GenLib.printAlamat(a:" Jl.Babakan Sirna", b:"Sukabumi");
        GenLib.printAlamat(a:"JL.Babakan Sirna", b:10);
    }
    
}
